package com.example.myapplication.data.mapper

import com.example.myapplication.data.model.UserDto
import com.example.myapplication.domain.model.User

object UserMapper {

    fun UserDto.toDomain(): User {
        return User(
            id = this.id,
            name = this.name,
            surname = this.surname
        )
    }

    fun User.toDto(): UserDto {
        return UserDto(
            id = this.id,
            name = this.name,
            surname = this.surname
        )
    }

    fun List<UserDto>.toDomain(): List<User> {
        return this.map { it.toDomain() }
    }

    fun List<User>.toDto(): List<UserDto> {
        return this.map { it.toDto() }
    }
}
