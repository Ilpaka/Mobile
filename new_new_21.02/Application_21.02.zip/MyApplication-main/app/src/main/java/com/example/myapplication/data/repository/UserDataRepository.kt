package com.example.myapplication.data.repository

import com.example.myapplication.data.model.UserDto
import kotlinx.coroutines.flow.Flow


interface UserDataRepository {
    fun getAllUsers(): Flow<List<UserDto>>

    suspend fun deleteUserByNameAndSurname(name: String, surname: String): Result<Boolean>

    suspend fun addUser(user: UserDto): Result<Unit>
}
