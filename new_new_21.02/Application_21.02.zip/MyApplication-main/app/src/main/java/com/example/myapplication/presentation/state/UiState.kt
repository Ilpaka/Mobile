package com.example.myapplication.presentation.state

import com.example.myapplication.domain.model.User


sealed class UiState {
    object Loading : UiState()

    data class Success(val users: List<User>) : UiState()

    data class Error(val message: String) : UiState()
}

sealed class DeleteState {

    object Idle : DeleteState()

    object Loading : DeleteState()

    data class Success(val deletedUserName: String) : DeleteState()

    data class Error(val message: String) : DeleteState()
}
