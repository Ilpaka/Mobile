package com.example.myapplication.domain.repository

import com.example.myapplication.domain.model.User
import kotlinx.coroutines.flow.Flow


interface UserRepository {
    fun getAllUsers(): Flow<List<User>>

    suspend fun deleteUserByNameAndSurname(name: String, surname: String): Result<Boolean>

    suspend fun addUser(user: User): Result<Unit>
}
