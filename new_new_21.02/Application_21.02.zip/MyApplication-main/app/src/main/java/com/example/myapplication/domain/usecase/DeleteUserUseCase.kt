package com.example.myapplication.domain.usecase

import com.example.myapplication.domain.repository.UserRepository
import javax.inject.Inject


class DeleteUserUseCase @Inject constructor(
    private val userRepository: UserRepository
) {

    suspend operator fun invoke(name: String, surname: String): Result<DeleteUserResult> {

        if (name.isBlank() || surname.isBlank()) {
            return Result.failure(
                IllegalArgumentException("Имя и фамилия не могут быть пустыми")
            )
        }

        val normalizedName = name.trim()
        val normalizedSurname = surname.trim()

        return try {
            val result = userRepository.deleteUserByNameAndSurname(normalizedName, normalizedSurname)

            result.fold(
                onSuccess = { deleted ->
                    if (deleted) {
                        Result.success(DeleteUserResult.Success(normalizedName, normalizedSurname))
                    } else {
                        Result.success(DeleteUserResult.UserNotFound(normalizedName, normalizedSurname))
                    }
                },
                onFailure = { exception ->
                    Result.failure(exception)
                }
            )
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}

sealed class DeleteUserResult {
    data class Success(val name: String, val surname: String) : DeleteUserResult()

    data class UserNotFound(val name: String, val surname: String) : DeleteUserResult()
}
