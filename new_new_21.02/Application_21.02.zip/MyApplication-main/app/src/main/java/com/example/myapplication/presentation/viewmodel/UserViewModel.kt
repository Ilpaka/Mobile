package com.example.myapplication.presentation.viewmodel


import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.myapplication.domain.usecase.DeleteUserUseCase
import com.example.myapplication.domain.usecase.DeleteUserResult
import com.example.myapplication.domain.repository.UserRepository
import com.example.myapplication.presentation.state.UiState
import com.example.myapplication.presentation.state.DeleteState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class UserViewModel @Inject constructor(
    private val userRepository: UserRepository,
    private val deleteUserUseCase: DeleteUserUseCase
) : ViewModel() {

    private val _uiState = MutableStateFlow<UiState>(UiState.Loading)
    private val _deleteState = MutableStateFlow<DeleteState>(DeleteState.Idle)
    private val _snackbarMessage = MutableSharedFlow<String>()

    val uiState: StateFlow<UiState> = _uiState.asStateFlow()
    val deleteState: StateFlow<DeleteState> = _deleteState.asStateFlow()
    val snackbarMessage: SharedFlow<String> = _snackbarMessage.asSharedFlow()

    init {
        loadUsers()
    }

    private fun loadUsers() {
        viewModelScope.launch {
            userRepository.getAllUsers()
                .catch { exception ->
                    _uiState.value = UiState.Error("Ошибка загрузки пользователей: ${exception.message}")
                }
                .collect { users ->
                    _uiState.value = UiState.Success(users)
                }
        }
    }

    fun deleteUser(name: String, surname: String) {
        viewModelScope.launch {
            _deleteState.value = DeleteState.Loading

            try {
                val result = deleteUserUseCase(name, surname)

                result.fold(
                    onSuccess = { deleteResult ->
                        when (deleteResult) {
                            is DeleteUserResult.Success -> {
                                _deleteState.value = DeleteState.Success(
                                    "${deleteResult.name} ${deleteResult.surname}"
                                )
                                _snackbarMessage.emit(
                                    "Пользователь ${deleteResult.name} ${deleteResult.surname} успешно удален"
                                )
                            }
                            is DeleteUserResult.UserNotFound -> {
                                _deleteState.value = DeleteState.Error(
                                    "Пользователь ${deleteResult.name} ${deleteResult.surname} не найден"
                                )
                                _snackbarMessage.emit(
                                    "Пользователь ${deleteResult.name} ${deleteResult.surname} не найден"
                                )
                            }
                        }
                    },
                    onFailure = { exception ->
                        val errorMessage = "Ошибка при удалении: ${exception.message}"
                        _deleteState.value = DeleteState.Error(errorMessage)
                        _snackbarMessage.emit(errorMessage)
                    }
                )
            } catch (e: Exception) {
                val errorMessage = "Неожиданная ошибка: ${e.message}"
                _deleteState.value = DeleteState.Error(errorMessage)
                _snackbarMessage.emit(errorMessage)
            } finally {
                // Сбросить состояние удаления через некоторое время
                kotlinx.coroutines.delay(2000)
                _deleteState.value = DeleteState.Idle
            }
        }
    }

    fun clearDeleteState() {
        _deleteState.value = DeleteState.Idle
    }

    fun refreshUsers() {
        _uiState.value = UiState.Loading
        loadUsers()
    }
}
