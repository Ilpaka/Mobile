package com.example.myapplication.data.repository


import com.example.myapplication.data.mapper.UserMapper.toDomain
import com.example.myapplication.data.mapper.UserMapper.toDto
import com.example.myapplication.domain.model.User
import com.example.myapplication.domain.repository.UserRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject

class UserRepositoryImpl @Inject constructor(
    private val userDataRepository: UserDataRepository
) : UserRepository {

    override fun getAllUsers(): Flow<List<User>> {
        return userDataRepository.getAllUsers().map { userDtoList ->
            userDtoList.toDomain()
        }
    }

    override suspend fun deleteUserByNameAndSurname(
        name: String,
        surname: String
    ): Result<Boolean> {
        return userDataRepository.deleteUserByNameAndSurname(name, surname)
    }

    override suspend fun addUser(user: User): Result<Unit> {
        return userDataRepository.addUser(user.toDto())
    }
}
