package com.example.myapplication.domain.model

data class User(
    val id: Int,
    val name: String,
    val surname: String
) {
    fun getFullName(): String = "$name $surname"

    fun matchesNameAndSurname(name: String, surname: String): Boolean {
        return this.name.equals(name, ignoreCase = true) &&
                this.surname.equals(surname, ignoreCase = true)
    }
}
