package com.example.myapplication.presentation.ui


import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.myapplication.databinding.FragmentUserListBinding
import com.example.myapplication.presentation.state.UiState
import com.example.myapplication.presentation.state.DeleteState
import com.example.myapplication.presentation.viewmodel.UserViewModel
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch

/**
 * Фрагмент для отображения списка пользователей с возможностью удаления
 */
@AndroidEntryPoint
class UserListFragment : Fragment() {

    private var _binding: FragmentUserListBinding? = null
    private val binding get() = _binding!!

    private val viewModel: UserViewModel by viewModels()
    private lateinit var userAdapter: UserAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentUserListBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupRecyclerView()
        setupObservers()
        setupRefreshListener()
    }

    /**
     * Настройка RecyclerView и адаптера
     */
    private fun setupRecyclerView() {
        userAdapter = UserAdapter { user ->
            showDeleteConfirmationDialog(user.name, user.surname)
        }

        binding.recyclerViewUsers.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = userAdapter
        }
    }

    /**
     * Настройка наблюдателей за изменениями состояния
     */
    private fun setupObservers() {
        // Наблюдение за состоянием UI
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.uiState.collect { state ->
                when (state) {
                    is UiState.Loading -> {
                        binding.progressBar.visibility = View.VISIBLE
                        binding.recyclerViewUsers.visibility = View.GONE
                        binding.textEmptyState.visibility = View.GONE
                    }
                    is UiState.Success -> {
                        binding.progressBar.visibility = View.GONE

                        if (state.users.isEmpty()) {
                            binding.recyclerViewUsers.visibility = View.GONE
                            binding.textEmptyState.visibility = View.VISIBLE
                        } else {
                            binding.recyclerViewUsers.visibility = View.VISIBLE
                            binding.textEmptyState.visibility = View.GONE
                            userAdapter.submitList(state.users)
                        }
                    }
                    is UiState.Error -> {
                        binding.progressBar.visibility = View.GONE
                        binding.recyclerViewUsers.visibility = View.GONE
                        binding.textEmptyState.visibility = View.VISIBLE
                        binding.textEmptyState.text = state.message
                    }
                }
            }
        }

        // Наблюдение за состоянием удаления
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.deleteState.collect { state ->
                when (state) {
                    is DeleteState.Loading -> {
                        // Можно показать индикатор загрузки
                    }
                    is DeleteState.Success -> {
                        // Успешное удаление обработается через snackbar
                    }
                    is DeleteState.Error -> {
                        // Ошибка будет показана через snackbar
                    }
                    is DeleteState.Idle -> {
                        // Обычное состояние
                    }
                }
            }
        }

        // Наблюдение за сообщениями Snackbar
        viewLifecycleOwner.lifecycleScope.launch {
            viewModel.snackbarMessage.collect { message ->
                Snackbar.make(binding.root, message, Snackbar.LENGTH_LONG).show()
            }
        }
    }

    /**
     * Настройка обновления по свайпу
     */
    private fun setupRefreshListener() {
        binding.swipeRefreshLayout.setOnRefreshListener {
            viewModel.refreshUsers()
            binding.swipeRefreshLayout.isRefreshing = false
        }
    }

    /**
     * Показать диалог подтверждения удаления
     */
    private fun showDeleteConfirmationDialog(name: String, surname: String) {
        MaterialAlertDialogBuilder(requireContext())
            .setTitle("Подтверждение удаления")
            .setMessage("Вы уверены, что хотите удалить пользователя $name $surname?")
            .setPositiveButton("Удалить") { _, _ ->
                viewModel.deleteUser(name, surname)
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
