package com.example.myapplication.data.repository

import com.example.myapplication.data.model.UserDto
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class FakeUserRepositoryImpl @Inject constructor() : UserDataRepository {

    // Внутреннее хранилище пользователей
    private val _users = MutableStateFlow(
        mutableListOf(
            UserDto(id = 1, name = "Иван", surname = "Иванов"),
            UserDto(id = 2, name = "Петр", surname = "Петров"),
            UserDto(id = 3, name = "Сидор", surname = "Сидоров"),
            UserDto(id = 4, name = "Анна", surname = "Смирнова"),
            UserDto(id = 5, name = "Елена", surname = "Козлова")
        )
    )

    private var nextId = 6 // Счетчик для новых ID

    override fun getAllUsers(): Flow<List<UserDto>> {
        return _users.asStateFlow()
    }

    override suspend fun deleteUserByNameAndSurname(
        name: String,
        surname: String
    ): Result<Boolean> {
        return try {
            val currentUsers = _users.value.toMutableList()
            val userToDelete = currentUsers.find {
                it.name.equals(name, ignoreCase = true) &&
                        it.surname.equals(surname, ignoreCase = true)
            }

            if (userToDelete != null) {
                currentUsers.remove(userToDelete)
                _users.value = currentUsers
                Result.success(true)
            } else {
                Result.failure(UserNotFoundException("Пользователь $name $surname не найден"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun addUser(user: UserDto): Result<Unit> {
        return try {
            val currentUsers = _users.value.toMutableList()
            val newUser = user.copy(id = nextId++)
            currentUsers.add(newUser)
            _users.value = currentUsers
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}

class UserNotFoundException(message: String) : Exception(message)
